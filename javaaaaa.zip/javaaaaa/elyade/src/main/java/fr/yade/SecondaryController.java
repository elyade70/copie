package fr.yade;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.paint.Color;

public class SecondaryController {
    @FXML
    private Button secondaryButton;

    @FXML
    private void switchToPrimary() throws IOException {
        App.setRoot("connexion");
    }

    @FXML
    void changecolor(ActionEvent event) {
        secondaryButton.setTextFill(Color.web("RED"));
    }
}
