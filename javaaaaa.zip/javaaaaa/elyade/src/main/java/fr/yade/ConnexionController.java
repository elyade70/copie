package fr.yade;

public class ConnexionController {

}
