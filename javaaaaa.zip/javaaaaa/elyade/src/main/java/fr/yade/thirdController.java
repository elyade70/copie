package fr.yade;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class thirdController {

    @FXML
    private TextField txtnuitééqté;

    @FXML
    private TextField txtnuitéemu;

    @FXML
    private TextField txtnuitéett;

    @FXML
    private TextField txtrepasqté;

    @FXML
    private TextField txtrepasmu;

    @FXML
    private TextField txtrepastt;

    public void initialize() {

        txtnuitéemu.setText("ekip");

    }
}