
module fr.yade {

    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;

    opens fr.yade to javafx.fxml;

    exports fr.yade;
}